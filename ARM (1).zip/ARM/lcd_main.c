#include<lpc21xx.h>
#include "header.h"
 main()
{
lcd_init();
lcd_data('A');
while(1);
}
