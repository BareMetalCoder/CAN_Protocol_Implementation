extern void uart0_init(unsigned int);
extern void uart0_tx(unsigned char);
