
extern void delay_sec(unsigned int);
extern void delay_ms(unsigned int);


