#include<lpc21xx.h>
main()
{
	  //IODIR0=1;
	  //IODIR0=0377;
//	  IODIR0=255<<0;
//	  IODIR0=0x7;
//	  IODIR0=1<<7;
//	  IODIR0=2<<10;
//	  IODIR0=2<<0;
//	  IODIR0=1<<10;
//	  IODIR0=0xFF;
//	  IODIR0=256;
	IODIR0=255;
//	  IOSET0=0xF0;
	 // IOSET0=240<<4;
	 IOSET0=15<<4;


}
